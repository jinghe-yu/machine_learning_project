"""Run a paired, fixed-budget Qwen smoke experiment using the existing sampler."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import platform
from statistics import fmean
import time
import urllib.request

from benchmark_utils import (
    append_result_csv,
    load_tasks,
    score_hypotheses,
    select_tasks,
    task_target_count,
    to_observations,
)
from boolean_genetics import sample_hypotheses


def request_json(url: str, payload: dict | None = None) -> dict:
    request = urllib.request.Request(
        url,
        data=json.dumps(payload).encode() if payload is not None else None,
        headers={"Content-Type": "application/json"},
    )
    with urllib.request.urlopen(request, timeout=90) as response:
        return json.load(response)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dataset", type=Path, default=Path("data/boolean_dataset.json"))
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--samples", type=int, default=10)
    parser.add_argument("--seed", type=int, default=42, help="Task selection seed")
    parser.add_argument("--base-url", default="http://127.0.0.1:8000/v1")
    parser.add_argument("--model", default="qwen3.8-27b")
    parser.add_argument("--factorial", action="store_true", help="Run six deduplication/feedback configurations plus an independent baseline")
    args = parser.parse_args()
    base_url = args.base_url.rstrip("/")
    metadata, all_tasks = load_tasks(args.dataset)
    tasks = select_tasks(all_tasks, args.samples, args.seed)
    models = request_json(f"{base_url}/models")
    if args.model not in {model["id"] for model in models["data"]}:
        parser.error(f"Model {args.model!r} is not served by {base_url}")
    methods = [("baseline", "none", False), ("ours_mechanistic", "mechanistic", True)]
    if args.factorial:
        methods = [("baseline", "none", False)] + [
            (f"ours_{dedup}" + ("" if feedback else "_no_feedback"), dedup, feedback)
            for dedup in ("mechanistic", "semantic", "none") for feedback in (True, False)
        ]
    args.output_dir.mkdir(parents=True, exist_ok=False)
    config = {
        "status": "running",
        "experiment": "six configurations plus independent baseline, single stochastic run" if args.factorial else "smoke only; not evidence of general performance",
        "methods": [method for method, _, _ in methods],
        "model": args.model,
        "base_url": base_url,
        "served_models": models,
        "python": platform.python_version(),
        "dataset": str(args.dataset.resolve()),
        "dataset_sha256": hashlib.sha256(args.dataset.read_bytes()).hexdigest(),
        "dataset_metadata": metadata,
        "source_sha256": {
            name: hashlib.sha256(Path(__file__).with_name(name).read_bytes()).hexdigest()
            for name in ("run_qwen_smoke.py", "boolean_genetics.py", "benchmark_utils.py")
        },
        "task_selection_seed": args.seed,
        "decoding_seed": None,
        "task_ids": [task["observation_set_id"] for task in tasks],
        "budget": "mechanistic ground-truth size per task, including rejected proposals",
        "temperature": 0.7,
        "max_tokens": 256,
        "enable_thinking": False,
        "started_at_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    }
    config_path = args.output_dir / "run_config.json"
    config_path.write_text(json.dumps(config, indent=2) + "\n", encoding="utf-8")
    summary = {}
    for method, deduplication, feedback in methods:
        rows = []
        usage = {"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0}
        elapsed = 0.0
        for index, task in enumerate(tasks, start=1):
            target = task_target_count(task, metadata["variables"], metadata.get("mechanistic_opts"))

            def complete(prompt: str, temperature: float) -> str:
                nonlocal elapsed
                payload = {
                    "model": args.model,
                    "messages": [
                        {"role": "system", "content": "You solve Boolean-genetics hypothesis discovery tasks."},
                        {"role": "user", "content": prompt},
                    ],
                    "temperature": temperature,
                    "max_tokens": config["max_tokens"],
                    "chat_template_kwargs": {"enable_thinking": False},
                }
                started = time.monotonic()
                response = request_json(f"{base_url}/chat/completions", payload)
                duration = time.monotonic() - started
                elapsed += duration
                for key in usage:
                    usage[key] += response.get("usage", {}).get(key, 0)
                record = {"method": method, "task_id": task["observation_set_id"],
                          "request": payload, "response": response, "elapsed_seconds": duration}
                with (args.output_dir / "requests.jsonl").open("a", encoding="utf-8") as file:
                    file.write(json.dumps(record, ensure_ascii=False) + "\n")
                return response["choices"][0]["message"]["content"] or ""

            sampled = sample_hypotheses(
                to_observations(task), complete, target,
                max_attempts=target, start_temperature=0.7, end_temperature=0.7,
                allowed_operators=metadata["operators"], max_depth=metadata["max_depth"],
                allow_constants=False, deduplication=deduplication,
                include_history=feedback, stop_on_target=False,
                mechanistic_options=metadata.get("mechanistic_opts"),
            )
            row = score_hypotheses(task, sampled.proposals, metadata, proposal_count=sampled.attempts)
            row.update(method=method, attempts=sampled.attempts,
                       rejection_counts=json.dumps(dict(sampled.rejection_counts)),
                       proposal_candidates_json=json.dumps(sampled.proposals),
                       raw_responses_json=json.dumps(sampled.raw_responses))
            append_result_csv(args.output_dir / f"{method}.csv", row)
            rows.append(row)
            print(f"{method} [{index}/{len(tasks)}] {task['observation_set_id']}: "
                  f"VR={row['validity_rate']:.1%} NR={row['novelty_rate']:.1%} "
                  f"RR={row['recovery_rate']:.1%} calls={sampled.attempts}", flush=True)
        summary[method] = {key: fmean(row[key] for row in rows) for key in (
            "validity_rate", "novelty_rate", "recovery_rate", "attempts")}
        summary[method].update(tasks=len(rows), calls=sum(row["attempts"] for row in rows),
                               usage=usage, api_elapsed_seconds=elapsed)
    (args.output_dir / "summary.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    config["status"] = "complete"
    config["completed_at_utc"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    config_path.write_text(json.dumps(config, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(summary, indent=2), flush=True)


if __name__ == "__main__":
    main()
